<?php get_header(); ?>
<div id="roll"><div title="回到顶部" id="roll_top"></div><div title="查看评论" id="ct"></div><div title="转到底部" id="fall"></div></div>
<div id="content">
<div class="main">
<div class="left">
<div class="articles">
<h3>抱歉，您打开的页面未能找到。<br />您可以使用本站的搜索框搜索您想要的内容，如有不便深感抱歉！</h3>
</div>
</div>
</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>