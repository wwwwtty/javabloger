<div class="pagenavi_badoo">
<?php if (function_exists('pagenavi')) { pagenavi(); } ?>
<div class="clearfix"></div>
</div>