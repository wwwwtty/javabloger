<form method="get" id="google_searchform" action="/site-search">
	<input type="text" value="Google自定义搜索..." name="q" id="s" onfocus="this.value = this.value == this.defaultValue ? '' : this.value" onblur="this.value = this.value == '' ? this.defaultValue : this.value" />
	<input type="submit" id="searchsubmit" value="搜 索" />
</form>