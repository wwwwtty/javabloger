	<div id="blogname"><a href="<?php echo get_option('home'); ?>"><?php bloginfo('name'); ?></a>
    <div id="blogtitle"><?php bloginfo('description'); ?></div></div>