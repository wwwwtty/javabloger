<!--footer start -->
<div id="footer">
	<div class="copyright">
		@<a href="http://www.wordpress.org/">WordPress</a> <?php bloginfo('version'); ?> | Theme by <a href="http://leotheme.cn">Await</a> | Host by <a href="http://idc.wopus.org/">Wopus</a> | <span class="gotop">返回顶部</span><br />
	</div>
</div>
<!--footer end -->
<?php wp_footer(); ?>
</body>
</html>